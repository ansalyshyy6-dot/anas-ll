package com.sada.walkie

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** خدمة أمامية: تُبقي اللاسلكي والمكالمات تعمل عند قفل الشاشة أو الخروج من التطبيق. */
class WalkieService : Service() {
    companion object {
        const val CHANNEL = "sada_radio"
        const val NOTIF_ID = 7
        const val ACTION_STOP = "com.sada.walkie.STOP"
        const val EXTRA_CALL = "call"
        private const val TXT_RADIO = "الجهاز اللاسلكي يعمل — اضغط للفتح"
        private const val TXT_CALL = "مكالمة جارية — اضغط للعودة"
    }

    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun build(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WalkieService::class.java).setAction(ACTION_STOP), flags
        )
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("صدى اللا سلكي")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stop)
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "اتصال صدى اللا سلكي", NotificationManager.IMPORTANCE_LOW)
            )
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, build(TXT_RADIO), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, build(TXT_RADIO))
            }
        } catch (_: Exception) {
            stopSelf(); return
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sada:radio").apply {
                setReferenceCounted(false); acquire(12 * 60 * 60 * 1000L)
            }
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifi = wm.createWifiLock(mode, "sada:wifi").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) {}
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) {
            Radio.get(this).stop()
            stopSelf()
            return START_NOT_STICKY
        }
        if (i != null && i.hasExtra(EXTRA_CALL)) {
            val inCall = i.getBooleanExtra(EXTRA_CALL, false)
            if (!inCall && !Radio.get(this).running) {
                stopSelf()
            } else {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(NOTIF_ID, build(if (inCall) TXT_CALL else TXT_RADIO))
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { wake?.release() } catch (_: Exception) {}
        try { wifi?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
