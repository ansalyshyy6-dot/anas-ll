pluginManagement {
    repositories {
        google()
        mavenCentral()
        // نسخة احتياطية من Maven Central على Google إذا رفض المصدر الأصلي (429)
        maven("https://maven-central.storage-download.googleapis.com/maven2/")
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven("https://maven-central.storage-download.googleapis.com/maven2/")
    }
}
rootProject.name = "SadaWalkie"
include(":app")
